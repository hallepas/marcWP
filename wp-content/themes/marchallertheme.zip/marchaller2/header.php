<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package marchaller
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

 <section class="slide intro" id="top">
    <div class="container">
        <div class="six columns alpha">
            <header class="title">
               <!-- <p>Marc Haller spielt</p>
                <h1 id="home"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                <h2><?php bloginfo( 'description' ); ?></h2>-->
                <img src="<?php echo get_template_directory_uri(); ?>/img/logo.jpg" alt="Marc Haller - Erwin aus der Schweiz" />
            </header>
            
            <nav id="site-navigation" class="main-nav" role="navigation">
                <ul class="site-nav" role="navigation">
                    <li class="site-nav__step current"><a href="#home">Home</a></li>
                    <li class="site-nav__step"><a href="#info">Info</a></li>
                    <li class="site-nav__step"><a href="#videos">Videos</a></li>
                    <li class="site-nav__step"><a href="#news">News</a></li>
                    <li class="site-nav__step"><a href="#kontakte">Kontakt</a></li>
                </ul>
            </nav>
        </div>
        <div class="js-portrait ten columns omega right-aligned">
            <img src="<?php echo get_template_directory_uri(); ?>/img/intro-portrait.jpg" class="stretch" />
        </div>
    </div>
</section>

